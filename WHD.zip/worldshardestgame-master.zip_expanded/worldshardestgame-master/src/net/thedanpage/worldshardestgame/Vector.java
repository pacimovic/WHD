package net.thedanpage.worldshardestgame;

import java.util.Random;

public class Vector {

	private int x;
	private int y;
	Random r=new Random();
	
	public Vector(int x,int y) {
		// TODO Auto-generated constructor stub
		this.x=x;
		this.y=y;
	}
	
	public void randomVector()
	{
		int pom=getRandom();
		x=pom;
		pom=getRandom();
		if(x!=0) y=0;
		else y=pom;
	}
	
	public int getRandom()
	{
		int k=r.nextInt(3)-1;
		return k;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
}
