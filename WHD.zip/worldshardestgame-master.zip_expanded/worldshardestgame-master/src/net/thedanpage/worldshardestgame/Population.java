package net.thedanpage.worldshardestgame;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

public class Population {

	private ArrayList<Player> players;
	private int populationSize = 100;
	private Player p;
	private Random randomGenerator=new Random();
	private ArrayList<Player>  matingpool;
	
	public Population() {
		// TODO Auto-generated constructor stub
		players=new ArrayList<Player>();
        for(int i = 0; i < populationSize; i++){
            p = new Player();
            players.add(p);
        }
	}
	
    public void evaluate(){
        double maxFit = 0;
        Player p=null
        		;
        for(int i = 0; i < populationSize; i++) {
            players.get(i).calcFitness(Game.getInstance().getTarget());;
            if (players.get(i).getFitness() > maxFit) {
                maxFit = players.get(i).getFitness();
                p=players.get(i);
            }
        }
        	
       
      //  System.out.println(maxFit);
        for(int i = 0; i < populationSize; i++){
            players.get(i).setFitness(players.get(i).getFitness()/maxFit); 
        }
        
        p.setFitness(p.getFitness()*10);
        
        matingpool = new ArrayList<Player>();
        for(int i = 0; i < populationSize; i++){
            double n = players.get(i).getFitness() * 100;
            for(int j = 0; j < n; j++){
                matingpool.add(players.get(i));
            }
        }
      
    }
    
    public void selection(){
        ArrayList<Player> newPlayers = new ArrayList<Player>();
        for(int i = 0; i < populationSize; i++){
            int index = randomGenerator.nextInt(matingpool.size());
            DNA parentA = matingpool.get(index).getDna();
            index = randomGenerator.nextInt(matingpool.size());
            DNA parentB = matingpool.get(index).getDna();
            DNA child;
            child = parentA.crossOver(parentB);
            child.mutation();
            newPlayers.add(new Player(child));

        }
        players = newPlayers;
    }
	
	public void run(Graphics g,GameLevel level)
	{
        for(int i = 0; i < populationSize; i++){
        	players.get(i).draw(g);
            players.get(i).update(level);     
        }
	}
	
	public void incrementMove()
	{
		Vector vr;
		for(Player p: players)
		{
			vr=new Vector(0, 0);
			vr.randomVector();
			p.getDna().getGenes().add(vr);
		}
	}
	
	public void respawnPlayers(GameLevel level)
	{
		for(Player p:players)
		{
			p.respawn(level);
			p.setBrojac(0);
		}
	}
	
	public void resetPlayers()
	{
		for(Player p:players)
		{
			p.reset();
		}
	}
	
	public ArrayList<Player> getPlayers() {
		return players;
	}
}
