package net.thedanpage.worldshardestgame;

import java.util.ArrayList;
import java.util.Random;

public class DNA {
	
	private ArrayList<Vector> genes=new ArrayList<Vector>();
	private Random rand;
	
	public DNA() {
		// TODO Auto-generated constructor stub
		for(int i=0;i<Game.lifeSpan/20+1;i++)
		{
			Vector vr=new Vector(0, 0);
			vr.randomVector();
			genes.add(vr);	
		}
	}
	
    public DNA(ArrayList<Vector> genes){
        this.genes = genes;
    }
	
	public DNA crossOver(DNA parentB) {
		
        ArrayList<Vector> newGenes = new ArrayList<Vector>();
        rand = new Random();
        int mid = rand.nextInt(genes.size());
        for(int i = 0; i < Game.lifeSpan/20+1; i++){
            if( i >mid){
                newGenes.add(genes.get(i));
            } else{
                newGenes.add(parentB.getGenes().get(i));
            }
        }
        return new DNA(newGenes);
	}
	
	public void mutation() {
		// TODO Auto-generated method stub
        for (int i = 0; i < genes.size(); i++){
            if(Math.random() < 0.005){
                Vector vec = new Vector(0,0);
                vec.randomVector();
                genes.set(i, vec);
              
            }
        }
	}
	
	public ArrayList<Vector> getGenes() {
		return genes;
	}


}
