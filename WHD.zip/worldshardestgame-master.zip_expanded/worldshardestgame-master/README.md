World's Hardest Game {WIP}
--------------------
A java version of World's Hardest Game, originally made by Armor Games and Snubby Land, recreated by Dan Convey.

Credits
-------
- Original game: http://www.snubbyland.com/
- Original game: http://armorgames.com/
- Sound effects: http://www.flashkit.com/
- Music: http://snayk.newgrounds.com/

Play the original
-----------------
http://www.worldshardestgame.org/

Make a new level
----------------
Check out the [project wiki](https://github.com/Dan95363/worldshardestgame/wiki) for a tutorial on creating levels for the game!

Included Libraries
------------------
- [TinySound](https://github.com/finnkuusisto/TinySound) by finnkuusisto
